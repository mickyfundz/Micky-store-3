const container = document.getElementById('productsContainer');
const searchInput = document.getElementById('searchInput');
const modal = document.getElementById('productModal');

let allProducts = [];

// ==============================
// Detect page and JSON
// ==============================
let jsonPath = '';
if (window.location.href.includes('glasses.html')) jsonPath = '../data/glasses.json'
if (window.location.href.includes('watches.html')) jsonPath = '../data/watches.json';
if (window.location.href.includes('caps.html')) jsonPath = '../data/caps.json';

// ==============================
// Fetch JSON
// ==============================
fetch(jsonPath)
  .then(res => res.json())
  .then(data => {
    const key = Object.keys(data)[0]; // glasses / watches / caps
    allProducts = data[key];
    displayProducts(allProducts);
    
    searchInput.addEventListener('input', () => {
      const value = searchInput.value.toLowerCase();
      const filtered = allProducts.filter(p => p.name.toLowerCase().includes(value));
      displayProducts(filtered);
    });
  });

// ==============================
// Display products
// ==============================
function displayProducts(products) {
  container.innerHTML = "";
  products.forEach(product => {
    container.innerHTML += `
        <div class="product-card" onclick='openModal(${JSON.stringify(product)})'>
            <img src="${product.image}" alt="">
            <h3>${product.name}</h3>
            <p>${product.description.substring(0,60)}...</p>
            <div class="price">$${product.price}</div>

            <!-- WhatsApp Order Button -->
            <button class="order-btn"
                onclick='event.stopPropagation(); orderOnWhatsApp(${JSON.stringify(product)})'>
                Order on WhatsApp
            </button>
        </div>
        `;
  });
}

// ==============================
// Product modal
// ==============================
function openModal(product) {
  modal.style.display = "flex";
  document.getElementById('modalImage').src = product.image;
  document.getElementById('modalTitle').innerText = product.name;
  document.getElementById('modalDescription').innerText = product.description;
  document.getElementById('modalPrice').innerText = "$" + product.price;
  
  const featuresList = document.getElementById('modalFeatures');
  featuresList.innerHTML = "";
  product.features.forEach(f => {
    featuresList.innerHTML += `<li>${f}</li>`;
  });
}

document.getElementById('closeModal').onclick = () => {
  modal.style.display = "none";
};

// ==============================
// WhatsApp order function (with image link)
// ==============================
function orderOnWhatsApp(product) {
  const phoneNumber = "2348089409172"; // Your WhatsApp number
  
  // Full image URL for customer to see
  const fullImageURL = window.location.origin + '/' + product.image;
  
  const message = `Hello, I want to order:

Product: ${product.name}
Price: $${product.price}
Description: ${product.description}

See product here: ${fullImageURL}`;
  
  const encodedMessage = encodeURIComponent(message);
  const url = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
  window.open(url, "_blank");
}